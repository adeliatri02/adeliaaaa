<?php 
$h='localhost';
$u = 'root';
$p = '';
$db ='domainku';
$connect = new mysqli($h, $u, $p, $db);
if ($connect->connect_error) {
	echo "gagal";
}
?>