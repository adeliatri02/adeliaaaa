<?php 
$conn = mysqli_connect("localhost","root","","domainku");


function query($query){
  global $conn;
  $result = mysqli_query($conn, $query);
  $rows = [];
  while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
  }
  return $rows;
}

  // HAPUS  Artikel
  function hapus($id){
     global $conn;
     mysqli_query($conn,"DELETE FROM artikel WHERE id = $id");
     return mysqli_affected_rows($conn);

  }


// Edit Berita
  function ubah($data){
    global $conn;
    $id       = $data["id"];
    $judul    = htmlspecialchars($data["judul"]);
    $penulis  = htmlspecialchars($data["penulis"]);
    $isi      = htmlspecialchars($data["isi"]);

    // query UPDATE data
    $query = "UPDATE artikel SET
                judul     = '$judul',
                penulis   = '$penulis',
                isi       = '$isi'
                WHERE id = $id
                ";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);

  }


    // HAPUS USER
  function hapususer($id){
     global $conn;
     mysqli_query($conn,"DELETE FROM user WHERE id = $id");
     return mysqli_affected_rows($conn);
  }

  // ubah user
function ubahuser ($data) { 
    global $conn;

    $id = $data["id"];
  $nama = htmlspecialchars($data["nama"]);
  $password = htmlspecialchars($data["password"]); 

  $query = "UPDATE daftar SET
      nama = '$nama',
      password = '$password'

      WHERE id = $id
      ";
  mysqli_query($conn,$query);

  return mysqli_affected_rows($conn);

}


?>