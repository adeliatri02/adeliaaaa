<?php
require 'proses_artikel.php';
$artikel = query("SELECT * FROM artikel ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Jenis jenis cover</title>
</head>
<body>
<link rel="stylesheet" href="css/styletampilberita.css">
  <body>
    <section>
      <div class="bts">
        <article class="" id="main-col">
              <?php $i = 1; foreach ( $artikel as $row ) : ?>
                <?php if ($i == 1): ?>
                  <div class="box">
                    <div class="new">
                      <p class="judul"><?= $row["judul"]; ?></p>
                      <p>Oleh : <?= $row["penulis"];  ?></p><hr>
                      <p><?= substr($row["isi"],0, 40);  ?></p>
                      <a href="readmore.php?id=<?= $row["id"];?>" style="text-decoration:none;"><button type="button" name="button" class="read">Read-more</button></a><br>
                      <a href="ubah_artikel.php?id=<?= $row["id"];?>" style="text-decoration:none;"><button type="button" name="button" class="read">Edit</button></a><br>
                      <a href="hapus_berita.php?id=<?= $row["id"];?>" onclick="return confirm('Anda yakin akan menghapus data?')" style="text-decoration:none;"><button type="button" name="button" class="read">Hapus</button></a>
                    </div>
                  </div>
                  <?php $i++; else: ?>
                    <section id="boxes">
                        <div class="box">
                          <div class="last">
                            <h3><?= $row["judul"]; ?></h3>
                            <p>Di tulis oleh : <?= $row["penulis"];  ?></p><hr>
                            <p><?= substr($row["isi"],0, 40);  ?></p>
                            <a href="readmore.php?id=<?= $row["id"];?>" style="text-decoration:none;"><button type="button" name="button" class="read">Read-more</button></a>

                            <a href="ubah_artikel.php?id=<?= $row["id"];?>" style="text-decoration:none;"><button type="button" name="button" class="read">Edit</button></a>

                            <a href="hapus_berita.php?id=<?= $row["id"]; ?>" onclick="return confirm('Anda yakin akan menghapus data?')"><button type="button" name="button" class="read">Hapus</button></a>

                          </div>
                        </div>

                    </section>
                <?php endif; ?>

              <?php endforeach; ?>

          </article>
        </div>
    </section>

  </body>
</html>