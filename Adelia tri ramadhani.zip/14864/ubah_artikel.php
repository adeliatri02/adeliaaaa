<?php
require 'proses_artikel.php';

$id = $_GET["id"];

$artikel = query("SELECT * FROM artikel WHERE id = $id")[0];

if (isset($_POST["submit"])) {

  if (ubah($_POST) > 0) {

 echo "
 <script>
   alert('Berita Berhasil Diubah!');
   document.location.href= 'dashboard.php';
 </script>
 ";
} else {
 echo "<script>
 alert('Berita Gagal Diubah');
 document.location.href='dashboard.php'
 </script>";
 }
}

?>

<!DOCTYPE html>
<html>
 <head>
   <meta charset="utf-8">
   <title>Edit Berita</title>
 </head>
 <link rel="stylesheet" href="css/styleubah_artikel.css">

 <body>
    <div class="sidebar">
      <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="artikel_tambah.php">Tambah Berita</a></li>
        <li><a href="daftaruser.php">Daftar User</a></li>
        <li><a href="about me.php">About Penulis</a></li>
        </ul>
    </div>
    <div class="bgjudul">
      <p class="merek">Sinopdrakor</p>
    </div>
    <div class="atas">
      <button class="tulisatas"><a href="logout.php" onclick="return confirm('Yakin Ingin Keluar ?');">Logout</a></button>
    </div>

    <h3 style="margin-bottom: 20px;">Edit pengguna</h3>
      <form action="" method="post">
       <div class="loginbox">
        <p>Judul</p>
       <input type="hidden" name="id" value="<?= $artikel["id"]; ?>">
       <input  type="text" name="judul" value="<?= $artikel["judul"]; ?>" autocomplete="off" placeholder="Judul" required><br><br>
       <p>Penulis</p>
       <input  type="text" required name="penulis" value="<?= $artikel["penulis"]; ?>" autocomplete="off" placeholder="penulis"><br>
       <p>Isi</p>
       <textarea style="resize:none;" name="isi" rows="9" cols="62" value="" placeholder="Isi" class="textarea"><?= $artikel["isi"]; ?></textarea>
       <br><br>

     <button type="submit" name="submit" class="submit">Simpan</button>
   
     <a href="dashboard.php" class="back">Kembali</a>
     <br>
     
   </div>
  </form>
 </body>
</html>
